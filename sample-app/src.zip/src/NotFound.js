import React, { Component } from 'react'

export class NotFound extends Component {
    render() {
        return (
            <div>
                <p>Page not Found</p>
            </div>
        )
    }
}

export default NotFound
