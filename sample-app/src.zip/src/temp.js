var x;
if (x === undefined)
    console.log("x is undefined");
if (typeof (x) == undefined)
    console.log("typeof(x) is undefined");

console.log(typeof (x))
