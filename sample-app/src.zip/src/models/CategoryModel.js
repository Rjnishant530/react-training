
export class CategoryModel {
    constructor(CategoryId = 0, CategoryName = '', Description = '') {
        this.CategoryId = CategoryId;
        this.CategoryName = CategoryName;
        this.Description = Description;
    }
}